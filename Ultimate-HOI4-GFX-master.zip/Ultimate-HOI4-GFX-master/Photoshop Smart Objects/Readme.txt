Custom flag smart objects for PS! Create any flag by just dragging it into a pre-made linked file
For specific symbols that needs to be visible try moving it either right or left in the flag image to correct for warping done on the actual icon

Credit to Gunnar Von Pontius